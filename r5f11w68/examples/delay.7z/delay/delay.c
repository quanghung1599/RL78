#include "delay.h"

void delay_init(void)
{
	
	PER0_bit.no0 = 1;
	TPS0 &= ~(0x0F);
	TPS0_bit.no0 = 1;
}

void delay_ms(uint32_t u32Delay)
{
	
	while (u32Delay) {
		TT0_bit.no0 = 1;
		IF0L_bit.no7 = 0;
		TDR00H = 0x27;
		TDR00L = 0x0F;
		TS0_bit.no0 = 1;
		while (!IF0L_bit.no7) {
		}
		--u32Delay;
	}
}
