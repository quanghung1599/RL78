#ifndef DELAY_H_
#define DELAY_H_

#include <ior5f11w68.h>
#include <ior5f11w68_ext.h>
#include <stdint.h>
#include <intrinsics.h>

void delay_init(void);
void delay_ms(uint32_t u32Delay);

#endif
