#include <ior5f11w68.h>
#include <ior5f11w68_ext.h>
#include <stdint.h>
#include <intrinsics.h>

#pragma location = "OPTBYTE"
__root const uint8_t opbyte0[4] = {0xEE, 0xFF, 0xF9, 0x05};

void delay(void);

void delay(void)
{
	uint32_t i;
	
	for (i = 0; i < 0x3ffff; ++i) {
		__no_operation();
	}
}

int main( void )
{
	//cau hinh chan P06 lam dau ra
	PM0_bit.no6 = 0;
	P0_bit.no6 = 0;
	POM0_bit.no6 = 0;
	PMC0_bit.no6 = 0;
	
	while (1) {
		P0_bit.no6 = 1;
		delay();
		P0_bit.no6 = 0;
		delay();
	}
}
